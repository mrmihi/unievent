// const Event = require('../models/event.model');
// const User = require('../models/user.model');

// const usersInDb = async () => {
//   const users = await User.find({});
//   return users.map((user) => user.toJSON());
// };

// module.exports = { usersInDb };
